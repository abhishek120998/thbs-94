﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MultiOptionDropdown.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using MultiOptionDropdown.Models;

namespace MultiOptionDropdown.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            Counrty list = new Counrty();
            list.Countries = BindList();
            return View(list);
        }
        [HttpPost]
        public IActionResult About(Counrty cnty)
        {
            cnty.Countries = BindList();
            if (cnty.Countryids!=null)
            {
                List<SelectListItem> selectedteditems = cnty.Countries.Where(p => cnty.Countryids.Contains(int.Parse(p.Value))).ToList();

                ViewBag.Message = "Selected Countries: ";
                foreach (var Selecteditem in selectedteditems)
                {
                    Selecteditem.Selected = true;
                    ViewBag.Message += Selecteditem.Text + ", ";
                }
            }
            return View(cnty);
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }
        public List<SelectListItem> BindList()
        {
            List<SelectListItem> list = new List<SelectListItem>();
            list.Add(new SelectListItem { Text = "India", Value = "1" });
            list.Add(new SelectListItem { Text = "USA", Value = "2" });
            list.Add(new SelectListItem { Text = "China", Value = "3" });
            list.Add(new SelectListItem { Text = "Japan", Value = "4" });
            return list;
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
