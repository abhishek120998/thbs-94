﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultiOptionDropdown.Models
{
    public class Counrty
    {
        public List<SelectListItem> Countries { get; set; }
        public int[] Countryids { get; set; }
    }
}
